# -*- coding: utf-8 -*-
"""Программа заливки: страница в браузере, работает только на этом пк.

Запуск — двойной клик по «Заливка.bat» (или python app.py). Сервер
слушает только 127.0.0.1, наружу ничего не открыто. Если уже запущен,
повторный запуск просто открывает страницу.

Шаги берутся из zaliv.py, данные — из базы (baza.py). Одновременно
идёт одна задача; её лог и ход видны на странице.
"""
import http.server
import io
import json
import mimetypes
import os
import socket
import sys
import threading
import time
import traceback
import urllib.parse
import webbrowser

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
os.chdir(HERE)

import baza   # noqa: E402
import proverka  # noqa: E402
import puti  # noqa: E402
import obnovlenie  # noqa: E402
import otchety  # noqa: E402
import zaliv  # noqa: E402

АДРЕС = ('127.0.0.1', 8765)
СТРАНИЦА = os.path.join(HERE, 'app', 'index.html')
ВЫБОР = puti.ВЫБОР
СКЛАДЫ = puti.СКЛАДЫ
ГОТОВЫЕ_ШАГИ = ['эксель']          # остальные появятся по мере готовности
ПРЕФИКС_НАЗВАНИЯ = 'Чехол на %s с принтом ' % zaliv.БАЗА_ИМЯ


def читать(путь, иначе=None):
    try:
        return json.load(io.open(путь, encoding='utf-8'))
    except (OSError, ValueError):
        return иначе


# ── база в памяти: перечитываем, только если база.json поменялась ──

_база = {'время': None, 'данные': None}
_база_замок = threading.Lock()


def база():
    with _база_замок:
        t = os.path.getmtime(baza.КАТАЛОГ) if os.path.exists(baza.КАТАЛОГ) else 0
        if _база['время'] != t:
            _база['данные'], _база['время'] = baza.загрузить(), t
        return _база['данные']


# ── задача: одна за раз ──

задача = {'статус': 'нет'}
_задача_замок = threading.Lock()
_отрисовка = threading.Semaphore(3)   # PSD тяжёлые — не больше трёх разом


def запустить(шаг, прогон_имя, функция):
    with _задача_замок:
        if задача.get('статус') == 'идёт':
            raise zaliv.Стоп('уже идёт задача: %s / %s' % (задача['прогон'], задача['шаг']))
        задача.clear()
        задача.update({'статус': 'идёт', 'шаг': шаг, 'прогон': прогон_имя, 'лог': [],
                       'сделано': 0, 'всего': 0, 'начало': time.time()})

    записано = [0]

    def лог(текст):
        задача['лог'].append(time.strftime('%H:%M:%S ') + str(текст))
        # лог прогона храним и на диске — пригодится для отчёта об ошибке
        п = os.path.join(zaliv.ПРОГОНЫ, задача.get('прогон') or '')
        if шаг in zaliv.ШАГИ and задача.get('прогон') and os.path.isdir(п):
            with io.open(os.path.join(п, 'лог.txt'), 'a', encoding='utf-8') as f:
                for строка in задача['лог'][записано[0]:]:
                    f.write(строка + '\n')
            записано[0] = len(задача['лог'])

    def прогресс(сделано, всего):
        задача['сделано'], задача['всего'] = сделано, всего

    def работа():
        try:
            имя = функция(лог, прогресс)
            if имя:
                задача['прогон'] = имя
            задача['статус'] = 'готово'
        except (zaliv.Стоп, obnovlenie.Ошибка) as e:
            лог('СТОП: %s' % e)
            задача['статус'] = 'ошибка'
        except BaseException as e:
            лог('ОШИБКА:\n' + traceback.format_exc())
            задача['статус'] = 'ошибка'
            автоотчёт(e)
        задача['конец'] = time.time()

    threading.Thread(target=работа, daemon=True).start()


# ── отчёты об ошибках ──

def согласие():
    return puti.настройки().get('отчёты')        # None — спросить, True/False


def автоотчёт(e):
    """Упал шаг по неожиданной причине — сохраняем отчёт, с согласия отправляем."""
    try:
        о = otchety.собрать('сбой', исключение=e, шаг=задача.get('шаг', ''),
                            прогон=задача.get('прогон', ''), лог=задача.get('лог', []))
        задача['отчёт'] = о['номер']
        задача['лог'].append(time.strftime('%H:%M:%S ') + 'сохранил отчёт об ошибке #%s' % о['номер'])
        if согласие() is True:
            threading.Thread(target=otchety.отправить, args=(о['номер'],), daemon=True).start()
    except Exception:
        pass


def ручной_отчёт(т):
    комментарий = (т.get('комментарий') or '').strip()
    if not комментарий and not т.get('скриншот'):
        raise zaliv.Стоп('напиши пару слов, что случилось, или приложи скриншот')
    прогон_ = (т.get('прогон') or '').strip()
    лог, подробности = [], {}
    if прогон_:
        п = os.path.join(zaliv.ПРОГОНЫ, прогон_)
        if os.path.isfile(os.path.join(п, 'лог.txt')):
            лог = io.open(os.path.join(п, 'лог.txt'), encoding='utf-8').read().splitlines()
        с = читать(os.path.join(п, 'состояние.json'), {}) or {}
        подробности = {'шаги': с.get('шаги'), 'моделей': len(с.get('модели', [])),
                       'дизайнов': len(с.get('дизайны', [])), 'настройки': с.get('настройки')}
    elif задача.get('лог'):
        лог = задача['лог']
    о = otchety.собрать('вручную', прогон=прогон_, лог=лог, комментарий=комментарий[:4000],
                        скриншот=т.get('скриншот'), подробности=подробности)
    ушёл = otchety.отправить(о['номер'])     # кнопку нажал сам — это и есть согласие
    return {'номер': о['номер'], 'отправлен': ушёл, 'отправка_есть': bool(otchety.dsn())}


def отчёт_окна(т):
    """Ошибка в самой странице (JS) — как автоотчёт, но без задачи."""
    о = otchety.собрать('окно', комментарий=str(т.get('сообщение', ''))[:1000],
                        подробности={'стек': str(т.get('стек', ''))[:4000], 'где': str(т.get('где', ''))[:300]})
    if согласие() is True:
        otchety.отправить(о['номер'])
    return {'номер': о['номер']}


def отчёты():
    return {'список': otchety.список(), 'согласие': согласие(), 'отправка_есть': bool(otchety.dsn())}


# ── данные для страницы ──

def топ_моделей():
    """Модели по заказам из выгрузки продаж — для кнопок ТОП 30 / ТОП 60."""
    ПРОДАЖИ = puti.настройки().get('продажи') or ''
    if not ПРОДАЖИ or not os.path.exists(ПРОДАЖИ):
        return []
    import openpyxl
    ws = openpyxl.load_workbook(ПРОДАЖИ, read_only=True, data_only=True)['Артикулы']
    заказы = {}
    шапка = None
    for r in ws.iter_rows(values_only=True):
        if шапка is None:
            шапка = list(r)
            continue
        с = dict(zip(шапка, r))
        if с.get('Модель'):
            заказы[с['Модель']] = заказы.get(с['Модель'], 0) + (с.get('Заказов') or 0)
    return [m for m, _ in sorted(заказы.items(), key=lambda x: -x[1])]


def топ_откуда():
    п = puti.настройки().get('продажи') or ''
    return time.strftime('%d.%m.%Y', time.localtime(os.path.getmtime(п))) if п and os.path.exists(п) else ''


def старт():
    б = база()
    профили = читать(zaliv.ПРОФИЛИ, {})
    сл = zaliv.словарь()
    пачки = {}
    for з in б['дизайны'].values():
        for п in з['пачки']:
            пачки[п] = пачки.get(п, 0) + 1
    моделей_в_наборе = {н: з['модели'] for н, з in б['мокапы'].items()}
    return {
        'профили': {и: dict(п, готов=bool(п.get('мокапы') and п['мокапы'] in б['мокапы']))
                    for и, п in профили.items() if и != '_'},
        'пачки': [{'имя': и, 'кол': к} for и, к in sorted(пачки.items(), key=lambda x: -x[1])],
        'мокапы': моделей_в_наборе,
        'названия_моделей': {m: сл[m]['наименование'] for н in моделей_в_наборе.values()
                             for m in н if m in сл},
        'инфографика': {и: з['файлы'] for и, з in б['инфографика'].items()},
        'видео': {и: з['файл'] for и, з in б['видео'].items()},
        'склады': [{'id': с['id'], 'имя': с['name']} for с in читать(СКЛАДЫ, [])
                   if not с.get('isDeleting')],
        'выбор': читать(ВЫБОР, {}),
        'топ': топ_моделей(),
        'топ_откуда': топ_откуда(),
        'шаги': zaliv.ШАГИ,
        'готовые_шаги': ГОТОВЫЕ_ШАГИ,
        'база': {'путь': baza.КОРЕНЬ, 'дизайнов': len(б['дизайны']),
                 'шаблоны': list(б['шаблоны'])},
        'настройки': настройки_для_окна(),
        'отчёты_согласие': согласие(),
    }


def настройки_для_окна():
    н = puti.настройки()
    return {
        'есть_токен': bool(puti.токен()),
        'база_выбрана': bool(н.get('база')),
        'магазин': н.get('магазин', ''),
        'права': н.get('права', []),
        'склады_когда': н.get('склады_когда', ''),
        'складов': len(читать(СКЛАДЫ, []) or []),
        'папка_базы': baza.КОРЕНЬ,
        'база_по_умолчанию': os.path.normpath(puti.БАЗА_ПО_УМОЛЧАНИЮ),
        'продажи': н.get('продажи', ''),
        'версия': puti.версия(),
        'установлена': puti.УСТАНОВЛЕНА,
        'программа': puti.ПРОГРАММА,
    }


# ── настройки продавца ──

def сохранить_токен(т):
    р = zaliv.проверить_токен(т)       # 401, мусор, нет сети — сюда не дойдёт
    puti.писать(puti.ТОКЕН, {'token': т.strip()})
    if р['склады'] is not None:
        puti.писать(СКЛАДЫ, р['склады'])
    puti.настройки_обновить(магазин=р['магазин'], права=р['права'], продавец_id=р['продавец_id'],
                            склады_когда=time.strftime('%d.%m.%Y %H:%M') if р['склады'] is not None else '')
    return {'магазин': р['магазин'], 'права': р['права'],
            'складов': len(р['склады']) if р['склады'] is not None else None}


def обновить_склады():
    код, о = zaliv.запрос('https://marketplace-api.wildberries.ru/api/v3/warehouses', метод='GET', попыток=3)
    if код != 200 or not isinstance(о, list):
        raise zaliv.Стоп('ВБ не отдал склады (код %s). Нужны права «Маркетплейс» у токена' % код)
    puti.писать(СКЛАДЫ, о)
    puti.настройки_обновить(склады_когда=time.strftime('%d.%m.%Y %H:%M'))
    return {'складов': len(о)}


def сменить_базу(путь_, создать=False):
    п = os.path.normpath((путь_ or '').strip() or puti.БАЗА_ПО_УМОЛЧАНИЮ)
    if not os.path.isdir(п):
        if not создать:
            raise zaliv.Стоп('нет такой папки: %s' % п)
        os.makedirs(п, exist_ok=True)
    проба = os.path.join(п, '.проба_записи')
    try:
        io.open(проба, 'w').close()
        os.remove(проба)
    except OSError:
        raise zaliv.Стоп('в эту папку нельзя писать: %s' % п)
    puti.настройки_обновить(база=п)
    baza.задать_корень(п)
    _база['время'] = None
    б = baza.загрузить()
    return {'папка': п, 'дизайнов': len(б['дизайны']), 'мокапов': len(б['мокапы'])}


def выгрузка_продаж(путь_):
    п = (путь_ or '').strip()
    if п and not os.path.isfile(п):
        raise zaliv.Стоп('нет такого файла: %s' % п)
    puti.настройки_обновить(продажи=п)
    return {'топ': len(топ_моделей())}


def дизайны():
    out = []
    for id_ in baza.по_порядку(база()['дизайны']):
        з = база()['дизайны'][id_]
        назв = str(з['строка'].get('Наименование', ''))
        if назв.startswith(ПРЕФИКС_НАЗВАНИЯ):
            назв = назв[len(ПРЕФИКС_НАЗВАНИЯ):]
        out.append({'id': id_, 'н': назв, 'п': з['пачки']})
    return out


def прогоны():
    out = []
    if os.path.isdir(zaliv.ПРОГОНЫ):
        for имя in os.listdir(zaliv.ПРОГОНЫ):
            с = читать(os.path.join(zaliv.ПРОГОНЫ, имя, 'состояние.json'))
            if not с:
                continue
            out.append({'имя': имя, 'создано': с.get('создано', ''), 'профиль': с.get('профиль'),
                        'моделей': len(с.get('модели', [])), 'дизайнов': len(с.get('дизайны', [])),
                        'шаги': {k: v.get('статус') for k, v in (с.get('шаги') or {}).items()}})
    return sorted(out, key=lambda x: x['создано'], reverse=True)


def прогон(имя):
    с = читать(os.path.join(zaliv.ПРОГОНЫ, имя, 'состояние.json'))
    if not с:
        raise zaliv.Стоп('нет прогона «%s»' % имя)
    экс = os.path.join(zaliv.ПРОГОНЫ, имя, 'эксели')
    с['имя'] = имя
    с['файлы'] = sorted(os.listdir(экс)) if os.path.isdir(экс) else []
    return с


def собрать(тело):
    выбор = {k: тело.get(k) for k in ('профиль', 'модели', 'дизайны', 'настройки')}
    json.dump(выбор, io.open(ВЫБОР, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    имя = (тело.get('прогон') or '').strip() or time.strftime('%Y-%m-%d-%H%M')
    if any(ch in имя for ch in '\\/:*?"<>|'):
        raise zaliv.Стоп('в имени прогона не должно быть \\ / : * ? " < > |')
    запустить('эксель', имя, lambda лог, прогресс: zaliv.собрать_эксели(
        тело['профиль'], тело.get('модели') or [], тело.get('дизайны') or [], (),
        имя, тело.get('настройки') or {}, лог=лог, прогресс=прогресс))
    return {'прогон': имя}


# ── добавление в базу из окна ──

ДИАЛОГ = r"""
import sys, json, tkinter as tk
from tkinter import filedialog
что, начало, заголовок = sys.argv[1], sys.argv[2], sys.argv[3]
r = tk.Tk(); r.withdraw(); r.attributes('-topmost', True)
if что == 'папка':
    о = filedialog.askdirectory(initialdir=начало or None, title=заголовок, mustexist=True)
elif что == 'эксель':
    о = filedialog.askopenfilename(initialdir=начало or None, title=заголовок,
                                   filetypes=[('Эксель', '*.xlsx'), ('Все файлы', '*.*')])
elif что == 'видео':
    о = filedialog.askopenfilename(initialdir=начало or None, title=заголовок,
                                   filetypes=[('Видео', '*.mp4 *.mov'), ('Все файлы', '*.*')])
else:
    о = filedialog.askopenfilenames(initialdir=начало or None, title=заголовок,
                                    filetypes=[('Картинки', '*.jpg *.jpeg *.png *.webp'), ('Все файлы', '*.*')])
    о = list(о)
sys.stdout.write(json.dumps(о, ensure_ascii=False))
"""


def выбрать(что, начало='', заголовок='Выбери'):
    """Обычное окно выбора Windows. Запускаем отдельным процессом: у tkinter
    свой цикл окон, в потоке сервера ему тесно."""
    import subprocess
    exe = sys.executable.replace('pythonw.exe', 'python.exe')
    р = subprocess.run([exe, '-c', ДИАЛОГ, что, начало or '', заголовок], capture_output=True,
                       creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0), timeout=600,
                       env=dict(os.environ, PYTHONIOENCODING='utf-8'))
    о = json.loads(р.stdout.decode('utf-8') or 'null')
    if isinstance(о, str):
        о = os.path.normpath(о) if о else ''
    elif isinstance(о, list):
        о = [os.path.normpath(x) for x in о]
    return {'выбрано': о}


def имя_в_базе(имя):
    имя = (имя or '').strip()
    if not имя or any(ch in имя for ch in '\\/:*?"<>|.') or len(имя) > 40:
        raise zaliv.Стоп('имя не подходит: без \\ / : * ? " < > | и точек, до 40 знаков')
    return имя


def проверить_в_базу(т):
    вид = т.get('вид')
    if вид == 'дизайны':
        return proverka.проверить_пачку(т['путь'], (т.get('имя') or '').strip())
    if вид == 'мокапы':
        return proverka.проверить_мокапы(т['путь'], (т.get('имя') or '').strip())
    if вид == 'инфографика':
        return proverka.проверить_инфографику(т.get('файлы') or [], (т.get('имя') or '').strip())
    if вид == 'видео':
        return proverka.проверить_видео(т['путь'], (т.get('имя') or '').strip())
    raise zaliv.Стоп('не понял, что добавляем')


def добавить_в_базу(т):
    вид, имя = т.get('вид'), имя_в_базе(т.get('имя'))
    отч = проверить_в_базу(т)          # перепроверяем: за это время могли что-то поменять
    if not отч['можно']:
        raise zaliv.Стоп('проверка не пройдена: ' + '; '.join(б['что'] for б in отч['ошибки']))
    if вид == 'дизайны':
        повторы = т.get('повторы') if т.get('повторы') in ('новые', 'старые') else None
        работа = lambda лог, пр: baza.импорт_дизайнов(т['путь'], имя, повторы, лог, отч.get('исключить', ()))
    elif вид == 'мокапы':
        работа = lambda лог, пр: baza.импорт_мокапов(т['путь'], имя, лог)
    elif вид == 'инфографика':
        работа = lambda лог, пр: baza.импорт_инфографики(т['файлы'], имя, лог)
    else:
        работа = lambda лог, пр: baza.импорт_видео(т['путь'], имя, лог)
    запустить('база', 'база', работа)
    return {'ок': True}


# ── http ──

class Обработчик(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def ответ(self, код, тело, тип='application/json; charset=utf-8', заголовки=()):
        if not isinstance(тело, bytes):
            тело = json.dumps(тело, ensure_ascii=False).encode('utf-8')
        self.send_response(код)
        self.send_header('Content-Type', тип)
        self.send_header('Content-Length', str(len(тело)))
        self.send_header('Cache-Control', 'no-store' if тип.startswith('application/json') else 'max-age=3600')
        for k, v in заголовки:
            self.send_header(k, v)
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(тело)

    def файл(self, путь, тип=None):
        тип = тип or mimetypes.guess_type(путь)[0] or 'application/octet-stream'
        размер = os.path.getsize(путь)
        диапазон = self.headers.get('Range', '')
        with open(путь, 'rb') as f:
            if диапазон.startswith('bytes='):   # видео в браузере просит кусками
                а, _, б = диапазон[6:].partition('-')
                а = int(а or 0)
                б = min(int(б) if б else размер - 1, размер - 1)
                f.seek(а)
                данные = f.read(б - а + 1)
                self.send_response(206)
                self.send_header('Content-Range', 'bytes %d-%d/%d' % (а, б, размер))
            else:
                данные = f.read()
                self.send_response(200)
            self.send_header('Content-Type', тип)
            self.send_header('Accept-Ranges', 'bytes')
            self.send_header('Content-Length', str(len(данные)))
            self.end_headers()
            self.wfile.write(данные)

    def база_отн(self, отн):
        """Путь внутри базы; за её пределы не выпускаем."""
        полный = os.path.realpath(baza.путь(отн))
        if not полный.startswith(os.path.realpath(baza.КОРЕНЬ) + os.sep) or not os.path.isfile(полный):
            raise FileNotFoundError(отн)
        return отн

    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        путь = urllib.parse.unquote(u.path)
        q = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
        try:
            if путь == '/':
                return self.файл(СТРАНИЦА, 'text/html; charset=utf-8')
            if путь == '/api/старт':
                return self.ответ(200, старт())
            if путь == '/api/дизайны':
                return self.ответ(200, дизайны())
            if путь == '/api/прогоны':
                return self.ответ(200, прогоны())
            if путь == '/api/прогон':
                return self.ответ(200, прогон(q['имя']))
            if путь == '/api/отчёты':
                return self.ответ(200, отчёты())
            if путь == '/api/обновления':
                return self.ответ(200, obnovlenie.состояние())
            if путь == '/api/задача':
                з = dict(задача)
                з['лог'] = list(задача.get('лог', []))[-400:]
                return self.ответ(200, з)
            if путь.startswith('/мини/'):
                return self.файл(baza.мини(self.база_отн(путь[len('/мини/'):])), 'image/jpeg')
            if путь.startswith('/рендер/'):
                части = путь[len('/рендер/'):].rsplit('.', 1)[0].split('/')
                if len(части) != 3 or any(ch in ''.join(части) for ch in '\\:.'):
                    raise FileNotFoundError(путь)
                набор, модель, диз = части
                with _отрисовка:
                    return self.файл(baza.отрисовка(набор, модель, диз), 'image/jpeg')
            if путь == '/внеш':          # превью картинки не из базы — для выбора инфографики
                ф = os.path.normpath(q.get('путь', ''))
                if not ф.lower().endswith(proverka.КАРТИНКИ) or not os.path.isfile(ф):
                    raise FileNotFoundError(ф)
                return self.файл(baza.мини_внеш(ф), 'image/jpeg')
            if путь == '/api/картинки':
                return self.ответ(200, proverka.картинки_в_папке(q.get('папка', '')))
            if путь.startswith('/файл/'):
                return self.файл(baza.путь(self.база_отн(путь[len('/файл/'):])))
            return self.ответ(404, {'ошибка': 'нет такой страницы'})
        except FileNotFoundError:
            return self.ответ(404, {'ошибка': 'нет файла'})
        except zaliv.Стоп as e:
            return self.ответ(400, {'ошибка': str(e)})
        except (ConnectionError, BrokenPipeError):
            pass
        except Exception:
            return self.ответ(500, {'ошибка': traceback.format_exc()})

    def do_POST(self):
        путь = urllib.parse.unquote(urllib.parse.urlparse(self.path).path)
        n = int(self.headers.get('Content-Length') or 0)
        тело = json.loads(self.rfile.read(n).decode('utf-8') or '{}') if n else {}
        try:
            if путь == '/api/собрать':
                return self.ответ(200, собрать(тело))
            if путь == '/api/папка':
                п = os.path.join(zaliv.ПРОГОНЫ, тело['имя'])
                os.startfile(п if os.path.isdir(п) else zaliv.ПРОГОНЫ)
                return self.ответ(200, {})
            if путь == '/api/выбрать':
                return self.ответ(200, выбрать(тело.get('что', 'папка'), тело.get('начало', ''),
                                              тело.get('заголовок', 'Выбери')))
            if путь == '/api/отчёт':
                return self.ответ(200, ручной_отчёт(тело))
            if путь == '/api/отчёт/окно':
                return self.ответ(200, отчёт_окна(тело))
            if путь == '/api/отчёт/отправить':
                otchety.одобрить(тело['номер'])
                return self.ответ(200, {'отправлен': otchety.отправить(тело['номер']),
                                        'отправка_есть': bool(otchety.dsn())})
            if путь == '/api/отчёты/согласие':
                з = тело.get('значение')
                puti.настройки_обновить(отчёты=з if з in (True, False) else None)
                if з is True:
                    threading.Thread(target=otchety.отправить_ждущие, args=(True,), daemon=True).start()
                return self.ответ(200, {'согласие': согласие()})
            if путь == '/api/обновления/проверить':
                return self.ответ(200, obnovlenie.проверить())
            if путь == '/api/обновления/поставить':
                в = str(тело.get('версия', ''))
                def работа(лог, пр):
                    obnovlenie.скачать(в, лог)
                    obnovlenie.переключить(в)
                    лог('версия %s выбрана — перезапусти программу, чтобы она включилась' % в)
                запустить('обновление', 'обновление', работа)
                return self.ответ(200, {'ок': True})
            if путь == '/api/обновления/перезапуск':
                if задача.get('статус') == 'идёт' and задача.get('шаг') != 'обновление':
                    raise zaliv.Стоп('сейчас идёт задача — дождись её конца')
                obnovlenie.перезапустить()
                self.ответ(200, {'ок': True})
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
            if путь == '/api/настройки/токен':
                return self.ответ(200, сохранить_токен(тело.get('токен', '')))
            if путь == '/api/настройки/склады':
                return self.ответ(200, обновить_склады())
            if путь == '/api/настройки/база':
                return self.ответ(200, сменить_базу(тело.get('путь'), bool(тело.get('создать'))))
            if путь == '/api/настройки/продажи':
                return self.ответ(200, выгрузка_продаж(тело.get('путь')))
            if путь == '/api/база/проверить':
                return self.ответ(200, проверить_в_базу(тело))
            if путь == '/api/база/добавить':
                return self.ответ(200, добавить_в_базу(тело))
            if путь == '/api/выход':
                self.ответ(200, {})
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
            return self.ответ(404, {'ошибка': 'нет такого действия'})
        except (zaliv.Стоп, obnovlenie.Ошибка, ValueError) as e:
            return self.ответ(400, {'ошибка': str(e)})
        except Exception:
            return self.ответ(500, {'ошибка': traceback.format_exc()})


def уже_запущен():
    with socket.socket() as s:
        s.settimeout(0.3)
        return s.connect_ex(АДРЕС) == 0


def main():
    url = 'http://%s:%d/' % АДРЕС
    if уже_запущен():
        webbrowser.open(url)
        return
    if sys.stdout is None or 'pythonw' in os.path.basename(sys.executable).lower():
        # без консоли — пишем в файл, чтобы было что посмотреть при сбое
        f = io.open(os.path.join(puti.ДАННЫЕ, 'app.log'), 'a', encoding='utf-8', buffering=1)
        sys.stdout = sys.stderr = f
    print('%s запуск %s' % (time.strftime('%Y-%m-%d %H:%M:%S'), url))
    сервер = http.server.ThreadingHTTPServer(АДРЕС, Обработчик)
    threading.Thread(target=lambda: otchety.отправить_ждущие(согласие() is True), daemon=True).start()
    if '--без-браузера' not in sys.argv:
        threading.Timer(0.5, webbrowser.open, [url]).start()
    try:
        сервер.serve_forever()
    finally:
        сервер.server_close()
        print('%s остановлен' % time.strftime('%Y-%m-%d %H:%M:%S'))


if __name__ == '__main__':
    main()
