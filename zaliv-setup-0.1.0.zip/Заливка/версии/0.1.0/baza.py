# -*- coding: utf-8 -*-
"""База заливки: дизайны, мокапы, инфографика, видео и шаблоны в одном месте.

Прога берёт всё только отсюда и по диску не ищет. Файлы кладутся
жёсткими ссылками (тот же диск — место не тратится, а исходник можно
двигать или удалять, в базе копия останется). Если ссылка не выходит
(другой диск), файл копируется.

  база_заливки/
    база.json                    каталог: что есть и откуда пришло
    дизайны/<id>.png             принт; строка экселя лежит в каталоге
    мокапы/<набор>/<модель>.psd
    инфографика/<набор>/02.jpg…  по порядку, как пойдут в карточку
    видео/<имя>.mp4
    шаблоны/<имя>.xlsx

Строка экселя дизайна хранится как есть, на iPhone 13 — модель
подставляется при сборке экселя.
"""
import glob
import io
import json
import os
import re
import shutil
import time

import openpyxl

import puti

КОРЕНЬ = КАТАЛОГ = None


def задать_корень(папка):
    """Папка базы продавца — из настроек; можно сменить на ходу."""
    global КОРЕНЬ, КАТАЛОГ
    КОРЕНЬ = os.path.normpath(папка)
    КАТАЛОГ = os.path.join(КОРЕНЬ, 'база.json')


задать_корень(puti.папка_базы())
СТРОКА_ШАПКИ, ПЕРВАЯ = 3, 5
БАЗА_АРТИКУЛ = 'iPhone_13_'
БАЗА_ИМЯ = 'iPhone 13'
ЛАТИНИЦА = re.compile(r'^[A-Za-z0-9_]+$')
ID_ДИЗАЙНА = re.compile(r'^[a-z]+\d+$')


def загрузить():
    if os.path.exists(КАТАЛОГ):
        return json.load(io.open(КАТАЛОГ, encoding='utf-8'))
    return {'дизайны': {}, 'мокапы': {}, 'инфографика': {}, 'видео': {}, 'шаблоны': {}}


def сохранить(к):
    os.makedirs(КОРЕНЬ, exist_ok=True)
    врем = КАТАЛОГ + '.tmp'
    json.dump(к, io.open(врем, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    os.replace(врем, КАТАЛОГ)


def путь(отн):
    return os.path.join(КОРЕНЬ, отн)


def положить(откуда, отн):
    """Кладёт файл в базу. Тот же файл повторно не трогаем."""
    куда = путь(отн)
    os.makedirs(os.path.dirname(куда), exist_ok=True)
    if os.path.exists(куда):
        if os.path.samefile(откуда, куда):
            return
        os.remove(куда)
    try:
        os.link(откуда, куда)
    except OSError:
        shutil.copy2(откуда, куда)


def строки_экселя(файл):
    """id дизайна → строка экселя на iPhone 13 (шапка → значение)."""
    ws = openpyxl.load_workbook(файл, read_only=True)['Товары']
    шапка, строки = None, {}
    for n, r in enumerate(ws.iter_rows(values_only=True), 1):
        if n == СТРОКА_ШАПКИ:
            шапка = r
        elif n >= ПЕРВАЯ and шапка:
            с = {k: v for k, v in zip(шапка, r) if k and v not in (None, '')}
            арт = с.get('Артикул продавца')
            if арт and арт.startswith(БАЗА_АРТИКУЛ):
                строки[арт[len(БАЗА_АРТИКУЛ):]] = с
    return строки


def _эксели(папка):
    return sorted((ф for ф in glob.glob(os.path.join(папка, '**', '*.xlsx'), recursive=True)
                   if not os.path.basename(ф).startswith('~$')), key=os.path.getmtime)


def _принты(папка):
    принты = {}
    for ф in glob.glob(os.path.join(папка, '**', '*.png'), recursive=True):
        принты[os.path.splitext(os.path.basename(ф))[0]] = ф
    return принты


def импорт_дизайнов(папка, пачка, повторы=None, лог=print, исключить=()):
    """Папка пачки: принты <id>.png и эксель(и) на iPhone 13 с их строками.

    Принт без строки или строка без принта в базу не идут — из них
    карточку не собрать. Повторный импорт обновляет записи.
    повторы — что делать со строкой дизайна, который уже есть в базе:
    'новые' — взять из этой пачки, 'старые' — оставить как было,
    None — взять из более свежего экселя.
    """
    к = загрузить()
    строки, время = {}, {}
    for ф in _эксели(папка):
        for id_, с in строки_экселя(ф).items():
            строки[id_], время[id_] = с, os.path.getmtime(ф)
    принты = _принты(папка)

    for id_ in исключить:          # проблемные по проверке — не берём
        принты.pop(id_, None)
        строки.pop(id_, None)
    без_строки = sorted(set(принты) - set(строки))
    без_принта = sorted(set(строки) - set(принты))
    новых = 0
    for id_ in по_порядку(set(принты) & set(строки)):
        отн = 'дизайны/%s.png' % id_
        з = к['дизайны'].get(id_)
        if з is None:
            новых += 1
            з = к['дизайны'][id_] = {'файл': отн, 'пачки': [], 'добавлен': time.strftime('%Y-%m-%d')}
            взять = True
        elif повторы == 'новые':
            взять = True
        elif повторы == 'старые':
            взять = False
        else:   # строку берём из самого свежего экселя, в каком бы порядке ни импортировали
            взять = время[id_] >= з.get('время_строки', 0)
        if взять or not os.path.exists(путь(отн)):
            положить(принты[id_], отн)
        if взять:
            з['строка'], з['время_строки'] = строки[id_], время[id_]
        if пачка not in з['пачки']:
            з['пачки'].append(пачка)
    сохранить(к)
    лог('пачка %s: %d дизайнов (новых %d)' % (пачка, len(set(принты) & set(строки)), новых))
    if без_строки:
        лог('  принт есть, строки в экселе нет — пропустил %d: %s' % (len(без_строки), кратко(без_строки)))
    if без_принта:
        лог('  строка есть, принта нет — пропустил %d: %s' % (len(без_принта), кратко(без_принта)))


def импорт_мокапов(папка, набор, лог=print):
    к = загрузить()
    модели = []
    for ф in sorted(glob.glob(os.path.join(папка, '*.psd'))):
        модель = os.path.splitext(os.path.basename(ф))[0]
        if not ЛАТИНИЦА.match(модель):
            лог('  в имени мокапа не только латиница, цифры и _ — пропустил: %s' % модель)
            continue
        положить(ф, 'мокапы/%s/%s.psd' % (набор, модель))
        модели.append(модель)
    к['мокапы'][набор] = {'папка': 'мокапы/' + набор, 'модели': модели,
                          'откуда': папка, 'добавлен': time.strftime('%Y-%m-%d')}
    сохранить(к)
    лог('мокапы %s: %d моделей' % (набор, len(модели)))


def импорт_инфографики(файлы, набор, лог=print):
    """Файлы по порядку — так и встанут в карточку после главного фото."""
    к = загрузить()
    старые = (к['инфографика'].get(набор) or {}).get('файлы', [])
    отн = []
    for i, ф in enumerate(файлы, 2):
        о = 'инфографика/%s/%02d%s' % (набор, i, os.path.splitext(ф)[1].lower())
        положить(ф, о)
        отн.append(о)
    for о in старые:   # при замене набора лишние слайды убираем
        if о not in отн and os.path.exists(путь(о)):
            os.remove(путь(о))
    к['инфографика'][набор] = {'файлы': отн, 'добавлен': time.strftime('%Y-%m-%d')}
    сохранить(к)
    лог('инфографика %s: %d слайдов' % (набор, len(отн)))


def импорт_видео(файл, имя, лог=print):
    к = загрузить()
    отн = 'видео/%s%s' % (имя, os.path.splitext(файл)[1].lower())
    положить(файл, отн)
    к['видео'][имя] = {'файл': отн, 'добавлен': time.strftime('%Y-%m-%d')}
    сохранить(к)
    лог('видео %s' % имя)


def импорт_шаблона(файл, имя):
    к = загрузить()
    отн = 'шаблоны/%s.xlsx' % имя
    положить(файл, отн)
    к['шаблоны'][имя] = {'файл': отн, 'добавлен': time.strftime('%Y-%m-%d')}
    сохранить(к)
    print('шаблон %s' % имя)


def мини(отн, размер=(300, 400)):
    """Превью картинки из базы (JPEG, кэш в превью/). Принты по 10 МБ —
    в интерфейс их целиком не тащим."""
    from PIL import Image
    исх = путь(отн)
    кэш = путь('превью/%s.jpg' % отн.replace('/', '__').rsplit('.', 1)[0])
    if os.path.exists(кэш) and os.path.getmtime(кэш) >= os.path.getmtime(исх):
        return кэш
    os.makedirs(os.path.dirname(кэш), exist_ok=True)
    Image.MAX_IMAGE_PIXELS = None
    im = Image.open(исх)
    im.draft('RGB', (размер[0] * 2, размер[1] * 2))  # для JPEG ускоряет, PNG игнорирует
    im.thumbnail(размер)
    if im.mode in ('RGBA', 'LA', 'P'):
        im = im.convert('RGBA')
        фон = Image.new('RGB', im.size, (238, 238, 238))
        фон.paste(im, mask=im.getchannel('A'))
        im = фон
    врем = кэш + '.tmp'
    im.convert('RGB').save(врем, 'JPEG', quality=82)
    os.replace(врем, кэш)
    return кэш


def отрисовка(набор, модель, дизайн):
    """Главное фото 900×1200: принт в мокап модели. Кэш в рендеры/<набор>/,
    перерисовываем, если поменялся мокап, принт или сама отрисовка."""
    import render_card
    мокап = путь('мокапы/%s/%s.psd' % (набор, модель))
    принт = путь('дизайны/%s.png' % дизайн)
    for ф in (мокап, принт):
        if not os.path.exists(ф):
            raise FileNotFoundError(ф)
    кэш = путь('рендеры/%s/%s_%s.jpg' % (набор, модель, дизайн))
    свежесть = max(os.path.getmtime(ф) for ф in (мокап, принт, render_card.__file__))  # и после правок отрисовки
    if os.path.exists(кэш) and os.path.getmtime(кэш) >= свежесть:
        return кэш
    os.makedirs(os.path.dirname(кэш), exist_ok=True)
    врем = кэш + '.tmp'
    render_card.собрать(мокап, принт).save(врем, 'JPEG', quality=92)
    os.replace(врем, кэш)
    return кэш


def мини_внеш(файл, размер=(300, 400)):
    """Превью картинки не из базы (выбор инфографики). Кэш по пути и времени."""
    import hashlib
    from PIL import Image
    ключ = hashlib.md5(('%s|%s' % (os.path.abspath(файл), os.path.getmtime(файл))).encode('utf-8')).hexdigest()
    кэш = путь('превью/_внеш/%s.jpg' % ключ)
    if os.path.exists(кэш):
        return кэш
    os.makedirs(os.path.dirname(кэш), exist_ok=True)
    im = Image.open(файл)
    im.thumbnail(размер)
    if im.mode in ('RGBA', 'LA', 'P'):
        im = im.convert('RGBA')
        фон = Image.new('RGB', im.size, (238, 238, 238))
        фон.paste(im, mask=im.getchannel('A'))
        im = фон
    im.convert('RGB').save(кэш, 'JPEG', quality=82)
    return кэш


def по_порядку(ids):
    """z2 раньше z10: сначала буквы, потом номер."""
    return sorted(ids, key=lambda d: (re.sub(r'\d+', '', d), int(re.sub(r'\D', '', d) or 0)))


def кратко(сп, n=8):
    return ', '.join(сп[:n]) + (' …' if len(сп) > n else '')


def сводка():
    к = загрузить()
    пачки = {}
    for з in к['дизайны'].values():
        for п in з['пачки']:
            пачки[п] = пачки.get(п, 0) + 1
    print('база: %s' % КОРЕНЬ)
    print('дизайны: %d (%s)' % (len(к['дизайны']),
                                ', '.join('%s %d' % kv for kv in sorted(пачки.items()))))
    for имя, н in к['мокапы'].items():
        print('мокапы %s: %d моделей' % (имя, len(н['модели'])))
    for имя, н in к['инфографика'].items():
        print('инфографика %s: %d слайдов' % (имя, len(н['файлы'])))
    print('видео: %s' % (', '.join(к['видео']) or '—'))
    print('шаблоны: %s' % (', '.join(к['шаблоны']) or '—'))
