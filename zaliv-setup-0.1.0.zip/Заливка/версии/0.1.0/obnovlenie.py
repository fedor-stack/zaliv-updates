# -*- coding: utf-8 -*-
"""Обновления: необязательные, с откатом на любую прошлую версию.

Источник — файл со списком версий (манифест) по ссылке из
общее/обновления.json (её задаёт производство; продавец может
переопределить в настройках, ключ «обновления»). Формат манифеста:

  {"версии": [{"версия": "0.2.0", "дата": "2026-10-12",
               "что_нового": ["…", "…"],
               "архив": "https://…/zaliv-0.2.0.zip",
               "sha256": "…", "размер": 123456}]}

Каждая версия ставится в свою папку версии/<номер>/ и не трогает
данные продавца. Переключение — запись номера в версии/текущая.txt
и перезапуск. Старые версии держим (последние ХРАНИТЬ), поэтому откат
мгновенный, а версию, которой уже нет на диске, можно скачать заново.
"""
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.request
import zipfile

import puti

ХРАНИТЬ = 5
ТЕКУЩАЯ = os.path.join(puti.ВЕРСИИ, 'текущая.txt')
РАБОЧАЯ = os.path.join(puti.ВЕРСИИ, 'последняя_рабочая.txt')
СБОЙ = os.path.join(puti.ДАННЫЕ, 'сбой_обновления.txt')
НУЖНЫЕ_ФАЙЛЫ = ('app.py', 'ВЕРСИЯ', 'puti.py', 'запуск.pyw')


class Ошибка(Exception):
    pass


def ключ(в):
    """'0.10.2' → (0, 10, 2) — чтобы 0.10 было новее 0.9."""
    return tuple(int(x) for x in re.findall(r'\d+', в)[:3]) or (0,)


def _прочитать(ф):
    try:
        return io.open(ф, encoding='utf-8').read().strip()
    except OSError:
        return ''


def адрес_манифеста():
    return (puti.настройки().get('обновления')
            or (puti.читать(os.path.join(puti.ОБЩЕЕ, 'обновления.json'), {}) or {}).get('манифест', ''))


def установленные():
    if not os.path.isdir(puti.ВЕРСИИ):
        return []
    out = []
    for и in os.listdir(puti.ВЕРСИИ):
        п = os.path.join(puti.ВЕРСИИ, и)
        if os.path.isdir(п) and _прочитать(os.path.join(п, 'ВЕРСИЯ')) == и:
            out.append(и)
    return sorted(out, key=ключ, reverse=True)


def состояние():
    сбой = _прочитать(СБОЙ)
    return {
        'установлена': puti.УСТАНОВЛЕНА,
        'текущая': puti.версия(),
        'рабочая': _прочитать(РАБОЧАЯ),
        'установленные': установленные(),
        'адрес': адрес_манифеста(),
        'сбой': сбой,
    }


def манифест():
    адрес = адрес_манифеста()
    if not адрес:
        raise Ошибка('источник обновлений пока не настроен')
    try:
        with urllib.request.urlopen(адрес, timeout=20) as r:
            м = json.loads(r.read().decode('utf-8'))
    except Exception as e:
        raise Ошибка('не получилось проверить обновления: %s' % e)
    версии = [в for в in м.get('версии', []) if в.get('версия') and в.get('архив')]
    return sorted(версии, key=lambda в: ключ(в['версия']), reverse=True)


def проверить():
    тек = puti.версия()
    все = манифест()
    у_меня = set(установленные())
    for в in все:
        в['новее'] = ключ(в['версия']) > ключ(тек)
        в['текущая'] = в['версия'] == тек
        в['на_диске'] = в['версия'] in у_меня
    import otchety
    return {'текущая': тек, 'новая': next((в for в in все if в['новее']), None), 'версии': все,
            'исправлено': otchety.исправленные(все)}


def _нужна_установка():
    if not puti.УСТАНОВЛЕНА:
        raise Ошибка('это рабочая копия для разработки — обновления работают только в установленной программе')


def скачать(версия, лог=print):
    """Ставит версию в версии/<номер>/, не переключаясь на неё."""
    _нужна_установка()
    if версия in установленные():
        лог('версия %s уже на диске' % версия)
        return
    в = next((x for x in манифест() if x['версия'] == версия), None)
    if not в:
        raise Ошибка('в списке обновлений нет версии %s' % версия)
    врем = os.path.join(puti.ВЕРСИИ, '_загрузка')
    shutil.rmtree(врем, ignore_errors=True)
    os.makedirs(врем)
    архив = os.path.join(врем, 'версия.zip')
    лог('качаю %s…' % версия)
    with urllib.request.urlopen(в['архив'], timeout=120) as r, open(архив, 'wb') as f:
        shutil.copyfileobj(r, f)
    if в.get('sha256'):
        h = hashlib.sha256(open(архив, 'rb').read()).hexdigest()
        if h != в['sha256']:
            shutil.rmtree(врем, ignore_errors=True)
            raise Ошибка('архив скачался битым (контрольная сумма не сошлась) — попробуй ещё раз')
    распак = os.path.join(врем, 'код')
    with zipfile.ZipFile(архив) as z:
        for имя in z.namelist():             # ничего не пишем за пределы папки
            if имя.startswith(('/', '\\')) or '..' in имя.replace('\\', '/').split('/'):
                raise Ошибка('в архиве странные пути — ставить не буду')
        z.extractall(распак)
    нет = [ф for ф in НУЖНЫЕ_ФАЙЛЫ if not os.path.exists(os.path.join(распак, ф))]
    if нет or _прочитать(os.path.join(распак, 'ВЕРСИЯ')) != версия:
        shutil.rmtree(врем, ignore_errors=True)
        raise Ошибка('архив версии %s неполный: %s' % (версия, ', '.join(нет) or 'не тот номер'))
    os.replace(распак, os.path.join(puti.ВЕРСИИ, версия))
    shutil.rmtree(врем, ignore_errors=True)
    лог('версия %s скачана' % версия)


def переключить(версия):
    """Делает версию текущей. Вступит в силу после перезапуска."""
    _нужна_установка()
    if версия not in установленные():
        raise Ошибка('версии %s нет на диске' % версия)
    io.open(ТЕКУЩАЯ, 'w', encoding='utf-8').write(версия)
    # запуск.pyw живёт в корне программы — берём из выбранной версии
    свой = os.path.join(puti.ВЕРСИИ, версия, 'запуск.pyw')
    if os.path.exists(свой):
        shutil.copyfile(свой, os.path.join(puti.ПРОГРАММА, 'запуск.pyw'))
    if os.path.exists(СБОЙ):
        os.remove(СБОЙ)
    почистить(версия)


def почистить(оставить):
    """Держим последние ХРАНИТЬ версий + текущую и последнюю рабочую."""
    нужные = {оставить, puti.версия(), _прочитать(РАБОЧАЯ)}
    for и in установленные()[ХРАНИТЬ:]:
        if и not in нужные:
            shutil.rmtree(os.path.join(puti.ВЕРСИИ, и), ignore_errors=True)


def перезапустить():
    """Запускает запуск.pyw, который дождётся, пока этот сервер закроется,
    и поднимет текущую версию. Сам сервер закрывает вызывающий."""
    exe = sys.executable
    флаги = 0x00000008 | 0x00000200   # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    subprocess.Popen([exe, os.path.join(puti.ПРОГРАММА, 'запуск.pyw'), '--после-перезапуска'],
                     cwd=puti.ПРОГРАММА, creationflags=флаги, close_fds=True)
