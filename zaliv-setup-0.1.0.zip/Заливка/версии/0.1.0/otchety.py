# -*- coding: utf-8 -*-
"""Отчёты об ошибках: сбор, чистка, хранение, отправка.

Отчёт складывается в данные/отчёты/<номер>.json (+ скриншот рядом)
и отправляется в Sentry-совместимый сборщик (Sentry или GlitchTip) —
ссылка (DSN) в общее/отчёты.json, её задаёт производство. Нет ссылки
или нет сети — отчёт ждёт и уйдёт при следующем запуске.

Что НЕ уходит никогда: токен ВБ, пути к папкам продавца (заменяются
на <база>, <программа>, ~), сами картинки (кроме скриншота, который
продавец приложил сам).

Согласие на автоотчёты при падении — настройка «отчёты»:
  None — спросить (отчёт сохранён, окно предложит отправить),
  True — отправлять сами, False — не отправлять (кнопка «Сообщить» работает всегда).
"""
import base64
import hashlib
import io
import json
import os
import platform
import random
import re
import shutil
import time
import traceback
import urllib.request
import uuid

import puti

ПАПКА = os.path.join(puti.ДАННЫЕ, 'отчёты')
СТРОК_ЛОГА = 200
БУКВЫ = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'      # без похожих O/0, I/1


def новый_номер():
    return ''.join(random.choice(БУКВЫ) for _ in range(6))


def _почистить(текст):
    """Токен и личные пути из любого текста отчёта."""
    if not isinstance(текст, str):
        return текст
    т = puti.токен()
    if т:
        текст = текст.replace(т, '<токен>')
    текст = re.sub(r'eyJ[A-Za-z0-9_\-]{20,}\.[A-Za-z0-9_\-]{20,}\.[A-Za-z0-9_\-]{10,}', '<токен>', текст)
    for путь_, метка in ((puti.папка_базы(), '<база>'), (puti.ПРОГРАММА, '<программа>'),
                         (os.path.expanduser('~'), '~')):
        for вид in {путь_, путь_.replace('\\', '/'), путь_.replace('/', '\\')}:
            if вид and len(вид) > 3:
                текст = текст.replace(вид, метка)
    return текст


def _чисто(о):
    if isinstance(о, dict):
        return {k: _чисто(v) for k, v in о.items()}
    if isinstance(о, list):
        return [_чисто(v) for v in о]
    return _почистить(о)


def отпечаток(тип, место, сообщение):
    """По нему сборщик склеивает одинаковые ошибки: числа и пути не важны."""
    м = re.sub(r'\d+', 'N', сообщение or '')[:120]
    return hashlib.sha1(('%s|%s|%s' % (тип, место, м)).encode('utf-8')).hexdigest()[:16]


def _место(тб):
    """Последняя строка трейсбэка из нашего кода — «файл:функция»."""
    наше = [к for к in traceback.extract_tb(тб) if os.path.dirname(os.path.abspath(к.filename)) == puti.КОД] \
        if тб else []
    к = (наше or traceback.extract_tb(тб) or [None])[-1] if тб else None
    return '%s:%s' % (os.path.basename(к.filename), к.name) if к else ''


def собрать(вид, *, исключение=None, шаг='', прогон='', лог=(), комментарий='',
            скриншот=None, подробности=None):
    """вид: 'сбой' (упал шаг), 'стоп' (прогон остановился по понятной причине),
    'вручную' (кнопка «Сообщить»), 'окно' (ошибка в самой странице)."""
    тип = сообщение = текст_тб = место = ''
    if исключение is not None:
        тип = type(исключение).__name__
        сообщение = str(исключение)
        тб = исключение.__traceback__
        текст_тб = ''.join(traceback.format_exception(type(исключение), исключение, тб))
        место = _место(тб)
    н = puti.настройки()
    отчёт = {
        'номер': новый_номер(),
        'вид': вид,
        'когда': time.strftime('%Y-%m-%d %H:%M:%S'),
        'версия': puti.версия(),
        'шаг': шаг,
        'прогон': прогон,
        'ошибка': {'тип': тип, 'сообщение': сообщение, 'место': место, 'трейсбэк': текст_тб},
        'отпечаток': отпечаток(тип or вид, место or шаг, сообщение or комментарий[:40]),
        'комментарий': комментарий,
        'лог': list(лог)[-СТРОК_ЛОГА:],
        'подробности': подробности or {},
        'магазин': н.get('магазин', ''),
        'продавец': hashlib.sha256(str(н.get('продавец_id', '')).encode()).hexdigest()[:12]
                    if н.get('продавец_id') else '',
        'система': {'windows': platform.platform(), 'python': platform.python_version(),
                    'свободно_гб': _свободно()},
        'скриншот': bool(скриншот),
        'отправлен': '',
    }
    отчёт = _чисто(отчёт)
    os.makedirs(ПАПКА, exist_ok=True)
    if скриншот:   # data:image/png;base64,... или голый base64
        данные = base64.b64decode(скриншот.split(',', 1)[-1])
        if len(данные) > 8 * 1024 * 1024:
            raise ValueError('скриншот больше 8 МБ')
        open(os.path.join(ПАПКА, отчёт['номер'] + '.png'), 'wb').write(данные)
    puti.писать(os.path.join(ПАПКА, отчёт['номер'] + '.json'), отчёт)
    return отчёт


def _свободно():
    try:
        return round(shutil.disk_usage(puti.папка_базы() if os.path.isdir(puti.папка_базы())
                                       else puti.ДАННЫЕ).free / 1024 ** 3, 1)
    except OSError:
        return None


def список():
    if not os.path.isdir(ПАПКА):
        return []
    out = []
    for ф in os.listdir(ПАПКА):
        if ф.endswith('.json'):
            о = puti.читать(os.path.join(ПАПКА, ф))
            if о:
                out.append({k: о.get(k) for k in ('номер', 'вид', 'когда', 'версия', 'шаг', 'прогон',
                                                  'комментарий', 'отправлен', 'скриншот')}
                           | {'ошибка': (о.get('ошибка') or {}).get('сообщение', '')})
    return sorted(out, key=lambda о: о['когда'], reverse=True)


def прочитать(номер):
    if not re.fullmatch(r'[A-Z0-9]{6}', номер or ''):
        raise ValueError('нет такого отчёта')
    о = puti.читать(os.path.join(ПАПКА, номер + '.json'))
    if not о:
        raise ValueError('нет такого отчёта')
    return о


# ── отправка (протокол Sentry: работает и с GlitchTip) ──

def dsn():
    return (puti.читать(os.path.join(puti.ОБЩЕЕ, 'отчёты.json'), {}) or {}).get('dsn', '')


def _разобрать_dsn(d):
    м = re.match(r'(https?)://([^@:]+)(?::[^@]*)?@([^/]+)/(?:(.*)/)?(\d+)$', d or '')
    if not м:
        return None
    схема, ключ, хост, путь_, проект = м.groups()
    return ключ, '%s://%s/%sapi/%s/envelope/' % (схема, хост, (путь_ + '/') if путь_ else '', проект)


def _событие(о):
    ош = о.get('ошибка') or {}
    уровень = {'сбой': 'error', 'окно': 'error', 'стоп': 'warning'}.get(о['вид'], 'info')
    с = {
        'event_id': uuid.uuid4().hex,
        'timestamp': time.time(),
        'platform': 'python',
        'level': уровень,
        'release': 'zaliv@' + о['версия'],
        'fingerprint': [о['отпечаток']],
        'tags': {'номер': о['номер'], 'вид': о['вид'], 'шаг': о['шаг'] or '-',
                 'магазин': о['магазин'] or '-'},
        'user': {'id': о['продавец']} if о.get('продавец') else {},
        'extra': {'лог': '\n'.join(о.get('лог') or []), 'подробности': о.get('подробности'),
                  'система': о.get('система'), 'прогон': о.get('прогон')},
    }
    if ош.get('тип'):
        с['exception'] = {'values': [{'type': ош['тип'], 'value': ош['сообщение'],
                                      'module': ош.get('место', '')}]}
        с['extra']['трейсбэк'] = ош.get('трейсбэк', '')
    else:
        с['message'] = {'formatted': ('[%s] %s' % (о['вид'], о.get('комментарий') or ош.get('сообщение') or ''))[:500]}
    if о.get('комментарий'):
        с['extra']['комментарий'] = о['комментарий']
    return с


def отправить(номер):
    """True — ушёл; False — некуда или нет сети (полежит до следующего раза)."""
    о = прочитать(номер)
    if о.get('отправлен'):
        return True
    р = _разобрать_dsn(dsn())
    if not р:
        return False
    ключ, адрес = р
    с = _событие(о)
    части = [json.dumps({'event_id': с['event_id'], 'dsn': dsn()}).encode(),
             json.dumps({'type': 'event'}).encode(), json.dumps(с, ensure_ascii=False).encode('utf-8')]
    скрин = os.path.join(ПАПКА, номер + '.png')
    if os.path.exists(скрин):
        данные = open(скрин, 'rb').read()
        части += [json.dumps({'type': 'attachment', 'length': len(данные), 'filename': 'скриншот.png',
                              'content_type': 'image/png'}, ensure_ascii=False).encode('utf-8'), данные]
    тело = b'\n'.join(части)
    req = urllib.request.Request(адрес, data=тело, method='POST', headers={
        'Content-Type': 'application/x-sentry-envelope',
        'X-Sentry-Auth': 'Sentry sentry_version=7, sentry_client=zaliv/%s, sentry_key=%s' % (о['версия'], ключ)})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            if r.status >= 300:
                return False
    except Exception:
        return False
    о['отправлен'] = time.strftime('%Y-%m-%d %H:%M:%S')
    puti.писать(os.path.join(ПАПКА, номер + '.json'), о)
    return True


def отправить_ждущие(можно_авто):
    """При запуске: дослать то, что не ушло. Автоотчёты — только с согласия."""
    if not dsn():
        return 0
    n = 0
    for к in список():
        if к['отправлен']:
            continue
        о = прочитать(к['номер'])
        if о['вид'] in ('сбой', 'окно', 'стоп') and not можно_авто and not о.get('одобрен'):
            continue
        n += отправить(о['номер'])
    return n


def одобрить(номер):
    о = прочитать(номер)
    о['одобрен'] = True
    puti.писать(os.path.join(ПАПКА, номер + '.json'), о)


def исправленные(манифест_версий):
    """Номера моих отчётов, которые отмечены исправленными в каких-то версиях."""
    мои = {о['номер'] for о in список()}
    out = {}
    for в in манифест_версий or []:
        for н in в.get('исправлено') or []:
            н = str(н).lstrip('#').upper()
            if н in мои:
                out[н] = в['версия']
    return out
