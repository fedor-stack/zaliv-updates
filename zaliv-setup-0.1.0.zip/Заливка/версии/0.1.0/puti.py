# -*- coding: utf-8 -*-
"""Где что лежит: код версии, общее от производства, данные продавца.

Установленная программа:
  <папка программы>/
    запуск.pyw              запускает текущую версию, при сбое откатывает
    версии/<номер>/         код версии (этот файл тоже тут) + общее/
    версии/текущая.txt      какая версия запускается
    данные/                 всё продавца — обновления сюда не лезут:
      настройки.json, токен.json, склады.json, последний_выбор.json,
      прогоны/, база/ (папка базы по умолчанию)

При разработке (код лежит не в «версии/…») папка программы — папка с кодом.
"""
import io
import json
import os

КОД = os.path.dirname(os.path.abspath(__file__))
УСТАНОВЛЕНА = os.path.basename(os.path.dirname(КОД)) == 'версии'
ПРОГРАММА = os.path.dirname(os.path.dirname(КОД)) if УСТАНОВЛЕНА else КОД
ВЕРСИИ = os.path.join(ПРОГРАММА, 'версии')
ДАННЫЕ = os.path.join(ПРОГРАММА, 'данные')
ОБЩЕЕ = os.path.join(КОД, 'общее')          # от производства, едет с версией

НАСТРОЙКИ = os.path.join(ДАННЫЕ, 'настройки.json')
ТОКЕН = os.path.join(ДАННЫЕ, 'токен.json')
СКЛАДЫ = os.path.join(ДАННЫЕ, 'склады.json')
ВЫБОР = os.path.join(ДАННЫЕ, 'последний_выбор.json')
ПРОГОНЫ = os.path.join(ДАННЫЕ, 'прогоны')
БАЗА_ПО_УМОЛЧАНИЮ = os.path.join(ДАННЫЕ, 'база')

СЛОВАРЬ = os.path.join(ОБЩЕЕ, 'словарь.json')
ПРОФИЛИ = os.path.join(ОБЩЕЕ, 'профили.json')
ШАБЛОНЫ = os.path.join(ОБЩЕЕ, 'шаблоны')

os.makedirs(ДАННЫЕ, exist_ok=True)


def версия():
    try:
        return io.open(os.path.join(КОД, 'ВЕРСИЯ'), encoding='utf-8').read().strip()
    except OSError:
        return '0.0.0'


def читать(путь, иначе=None):
    try:
        return json.load(io.open(путь, encoding='utf-8'))
    except (OSError, ValueError):
        return иначе


def писать(путь, данные):
    os.makedirs(os.path.dirname(путь), exist_ok=True)
    врем = путь + '.tmp'
    json.dump(данные, io.open(врем, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    os.replace(врем, путь)


def настройки():
    return читать(НАСТРОЙКИ, {}) or {}


def настройки_обновить(**что):
    н = настройки()
    н.update(что)
    писать(НАСТРОЙКИ, н)
    return н


def папка_базы():
    return настройки().get('база') or БАЗА_ПО_УМОЛЧАНИЮ


def токен():
    return (читать(ТОКЕН, {}) or {}).get('token', '')
