# -*- coding: utf-8 -*-
"""Собирает готовое фото карточки: мокап модели плюс принт.

То же, что делает автоматика хозяина, только локально: кладём дизайн
в слой ff_main (он лежит под чехлом), сводим и отдаём JPG 900x1200 —
ровно то, что уходит на ВБ главным фото.

Запуск: python render_card.py <модель> <дизайн.png> <куда.jpg> [набор мокапов]
Мокап берётся из базы (baza.py), по умолчанию набор «тикток».
"""
import sys

from PIL import Image
from psd_tools import PSDImage
from psd_tools.api.layers import PixelLayer

Image.MAX_IMAGE_PIXELS = None


def собрать(мокап, принт):
    """Подменяем слой ff_main принтом и сводим весь PSD средствами psd_tools.

    Слои над принтом (чехол, камера, блики) в мокапах наложены разными
    режимами — линейный затемнитель, умножение, перекрытие, яркость…
    Их надо считать как Фотошоп: при обычном наложении белый слой чехла
    в «линейном затемнителе» закрывал принт целиком (iPhone 15 и ещё 34).
    """
    psd = PSDImage.open(мокап)
    # ff_main бывает и не один (realme_7pro в «новых») — подменяем все
    места = [l for l in psd if (l.name or '').strip().lower() == 'ff_main']
    if not места:
        raise ValueError('в мокапе нет слоя ff_main: %s' % мокап)
    исходник = Image.open(принт).convert('RGBA')
    for ff in места:
        # принт растягиваем по рамке ff_main и режем по его форме
        x1, y1, x2, y2 = ff.bbox
        форма = ff.composite(viewport=ff.bbox)
        диз = исходник.resize((x2 - x1, y2 - y1), Image.LANCZOS)
        if форма:
            диз.putalpha(Image.composite(диз.getchannel('A'), Image.new('L', диз.size, 0),
                                         форма.convert('RGBA').getchannel('A')))
        psd.insert(list(psd).index(ff), PixelLayer.frompil(диз, psd, 'ff_main', y1, x1))
        psd.remove(ff)
    return psd.composite(force=True).convert('RGB')


if __name__ == '__main__':
    import baza
    модель, принт, куда = sys.argv[1], sys.argv[2], sys.argv[3]
    набор = sys.argv[4] if len(sys.argv) > 4 else 'тикток'
    мокап = baza.путь('мокапы/%s/%s.psd' % (набор, модель))
    собрать(мокап, принт).save(куда, 'JPEG', quality=92)
    print('готово:', куда)
