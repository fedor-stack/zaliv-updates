# -*- coding: utf-8 -*-
"""Запускалка программы: лежит в корне установленной программы.

Поднимает версию из версии/текущая.txt. Если она не запустилась за
полминуты — возвращает последнюю рабочую (версии/последняя_рабочая.txt)
и оставляет записку в данные/сбой_обновления.txt, окно её покажет.
Если программа уже запущена — просто открывает страницу.
"""
import io
import os
import re
import socket
import subprocess
import sys
import time
import webbrowser

ПРОГРАММА = os.path.dirname(os.path.abspath(__file__))
ВЕРСИИ = os.path.join(ПРОГРАММА, 'версии')
ДАННЫЕ = os.path.join(ПРОГРАММА, 'данные')
ТЕКУЩАЯ = os.path.join(ВЕРСИИ, 'текущая.txt')
РАБОЧАЯ = os.path.join(ВЕРСИИ, 'последняя_рабочая.txt')
АДРЕС = ('127.0.0.1', 8765)
URL = 'http://127.0.0.1:%d/' % АДРЕС[1]


def отвечает():
    with socket.socket() as s:
        s.settimeout(0.3)
        return s.connect_ex(АДРЕС) == 0


def прочитать(ф):
    try:
        return io.open(ф, encoding='utf-8').read().strip()
    except OSError:
        return ''


def записать(ф, текст):
    os.makedirs(os.path.dirname(ф), exist_ok=True)
    io.open(ф, 'w', encoding='utf-8').write(текст)


def ключ(в):
    return tuple(int(x) for x in re.findall(r'\d+', в)[:3]) or (0,)


def сообщение(текст):
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, текст, 'Заливка', 0x10)
    except Exception:
        pass


def поднять(версия):
    app = os.path.join(ВЕРСИИ, версия, 'app.py')
    if not версия or not os.path.exists(app):
        return False
    os.makedirs(ДАННЫЕ, exist_ok=True)
    журнал = open(os.path.join(ДАННЫЕ, 'запуск.log'), 'a', encoding='utf-8')
    журнал.write('\n%s запускаю %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), версия))
    журнал.flush()
    п = subprocess.Popen([sys.executable, app, '--без-браузера'], cwd=os.path.dirname(app),
                         stdout=журнал, stderr=журнал,
                         creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    for _ in range(60):
        if п.poll() is not None:
            return False
        if отвечает():
            return True
        time.sleep(0.5)
    п.kill()
    return False


def main():
    после = '--после-перезапуска' in sys.argv
    if после:                       # ждём, пока старая копия закроется
        for _ in range(40):
            if not отвечает():
                break
            time.sleep(0.5)
    elif отвечает():
        webbrowser.open(URL)
        return

    есть = sorted((и for и in os.listdir(ВЕРСИИ) if os.path.isdir(os.path.join(ВЕРСИИ, и))
                   and os.path.exists(os.path.join(ВЕРСИИ, и, 'app.py'))), key=ключ, reverse=True) \
        if os.path.isdir(ВЕРСИИ) else []
    тек = прочитать(ТЕКУЩАЯ) or (есть[0] if есть else '')
    раб = прочитать(РАБОЧАЯ)

    if поднять(тек):
        записать(РАБОЧАЯ, тек)
        if not после:
            webbrowser.open(URL)
        return
    запасная = раб if раб and раб != тек else next((и for и in есть if и != тек), '')
    if запасная and поднять(запасная):
        записать(ТЕКУЩАЯ, запасная)
        записать(РАБОЧАЯ, запасная)
        записать(os.path.join(ДАННЫЕ, 'сбой_обновления.txt'),
                 'Версия %s не запустилась — вернул %s. Подробности: данные\\запуск.log' % (тек, запасная))
        if not после:
            webbrowser.open(URL)
        return
    сообщение('Программа не запустилась.\nПодробности в файле:\n%s'
              % os.path.join(ДАННЫЕ, 'запуск.log'))


if __name__ == '__main__':
    main()
